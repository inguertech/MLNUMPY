Wrappers
=========

``WrapperBase``
---------------
.. autoclass:: numpy_ml.neural_nets.wrappers.wrappers.WrapperBase
    :members:
    :undoc-members:
    :inherited-members:

``Dropout``
-----------
.. autoclass:: numpy_ml.neural_nets.wrappers.Dropout
    :members:
    :undoc-members:
    :show-inheritance:
