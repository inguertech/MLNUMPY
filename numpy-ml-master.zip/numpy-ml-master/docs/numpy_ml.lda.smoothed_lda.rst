``SmoothedLDA``
===============

.. autoclass:: numpy_ml.lda.SmoothedLDA
    :members:
    :undoc-members:
    :inherited-members:
    :show-inheritance:
