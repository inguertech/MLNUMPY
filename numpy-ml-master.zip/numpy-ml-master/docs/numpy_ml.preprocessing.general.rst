General
#######

``FeatureHasher``
-----------------

.. autoclass:: numpy_ml.preprocessing.general.FeatureHasher
	:members:
	:undoc-members:
	:inherited-members:

``OneHotEncoder``
-----------------

.. autoclass:: numpy_ml.preprocessing.general.OneHotEncoder
	:members:
	:undoc-members:
	:inherited-members:

``Standardizer``
----------------

.. autoclass:: numpy_ml.preprocessing.general.Standardizer
	:members:
	:undoc-members:
	:inherited-members:

``minibatch``
-------------

.. automodule:: numpy_ml.preprocessing.general
	:members: minibatch
